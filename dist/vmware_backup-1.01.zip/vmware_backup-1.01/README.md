VMWare-Backup
=============

Python based vmware backup script
